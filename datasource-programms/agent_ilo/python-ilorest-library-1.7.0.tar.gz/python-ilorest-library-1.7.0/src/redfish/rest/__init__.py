""" Utilities to simplify interaction with Redfish data """
