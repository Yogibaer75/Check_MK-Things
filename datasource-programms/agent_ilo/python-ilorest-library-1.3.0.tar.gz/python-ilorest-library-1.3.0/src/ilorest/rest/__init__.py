"""
Utilities to simplify interaction with V1 and redfish data
"""
